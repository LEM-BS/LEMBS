Object.defineProperty(document, 'readyState', {
  configurable: true,
  value: 'complete'
});
